/**
 * state.js — Capa de persistencia local (localStorage) de Crypto Treasury Pro.
 * No hay backend: todo lo que ve el usuario aquí vive en su propio navegador.
 * Esto sirve como contrato de datos para cuando se conecte un backend real
 * (ver docs.html → "Integración futura").
 */
const CTP_KEYS = {
  SESSION: 'ctp_session',
  WALLET: 'ctp_wallet_conn',
  SETTINGS: 'ctp_settings',
  ALERTS: 'ctp_alerts',
  WALLETS: 'ctp_wallets_custom',
  USERS: 'ctp_users',
  LOGS: 'ctp_logs',
};

function ctpRead(key, fallback) {
  try {
    const raw = localStorage.getItem(key);
    return raw ? JSON.parse(raw) : fallback;
  } catch (e) {
    console.warn('ctp state: no se pudo leer', key, e);
    return fallback;
  }
}
function ctpWrite(key, value) {
  try {
    localStorage.setItem(key, JSON.stringify(value));
    return true;
  } catch (e) {
    console.warn('ctp state: no se pudo escribir', key, e);
    return false;
  }
}

const State = {
  /* ---------- Sesión ---------- */
  getSession() { return ctpRead(CTP_KEYS.SESSION, null); },
  setSession(session) {
    ctpWrite(CTP_KEYS.SESSION, { ...session, loggedInAt: Date.now() });
    State.addLog('Inicio de sesión', session.email || session.wallet || 'usuario', 'info');
  },
  clearSession() {
    localStorage.removeItem(CTP_KEYS.SESSION);
    localStorage.removeItem(CTP_KEYS.WALLET);
    State.addLog('Cierre de sesión', '—', 'info');
  },

  /* ---------- Wallet conectada ---------- */
  getWalletConn() { return ctpRead(CTP_KEYS.WALLET, null); },
  setWalletConn(address) {
    ctpWrite(CTP_KEYS.WALLET, { address, connectedAt: Date.now() });
    State.addLog('Wallet conectada', address, 'info');
  },

  /* ---------- Configuración de usuario ---------- */
  getSettings() {
    return ctpRead(CTP_KEYS.SETTINGS, {
      theme: 'dark',
      baseCurrency: 'USDT',
      favoriteExchange: 'Binance',
      mainWallet: 'Cold Storage Treasury #1',
    });
  },
  saveSettings(patch) {
    const next = { ...State.getSettings(), ...patch };
    ctpWrite(CTP_KEYS.SETTINGS, next);
    State.addLog('Configuración actualizada', Object.keys(patch).join(', '), 'info');
    return next;
  },

  /* ---------- Alertas (CRUD) ---------- */
  getAlerts() {
    const existing = ctpRead(CTP_KEYS.ALERTS, null);
    if (existing) return existing;
    const seed = [
      { id: 'a1', metric: 'var95', label: 'VaR 95% (1 día)', unit: '$M', comparator: 'gte', threshold: 4.0, enabled: true, createdAt: Date.now() },
      { id: 'a2', metric: 'voleth', label: 'Volatilidad anualizada — ETH', unit: '%', comparator: 'gte', threshold: 65, enabled: true, createdAt: Date.now() },
      { id: 'a3', metric: 'drawdown', label: 'Drawdown máximo (30d)', unit: '%', comparator: 'gte', threshold: 14, enabled: true, createdAt: Date.now() },
    ];
    ctpWrite(CTP_KEYS.ALERTS, seed);
    return seed;
  },
  saveAlerts(list) { ctpWrite(CTP_KEYS.ALERTS, list); },
  addAlert(alert) {
    const list = State.getAlerts();
    const item = { id: 'a' + Date.now(), enabled: true, createdAt: Date.now(), ...alert };
    list.unshift(item);
    State.saveAlerts(list);
    State.addLog('Alerta creada', alert.label, 'info');
    return item;
  },
  updateAlert(id, patch) {
    const list = State.getAlerts().map(a => a.id === id ? { ...a, ...patch } : a);
    State.saveAlerts(list);
    State.addLog('Alerta editada', id, 'info');
  },
  deleteAlert(id) {
    const list = State.getAlerts().filter(a => a.id !== id);
    State.saveAlerts(list);
    State.addLog('Alerta eliminada', id, 'warning');
  },

  /* ---------- Wallets agregadas por el usuario ---------- */
  getCustomWallets() { return ctpRead(CTP_KEYS.WALLETS, []); },
  addCustomWallet(wallet) {
    const list = State.getCustomWallets();
    const item = { id: 'w' + Date.now(), status: 'Activa', ...wallet };
    list.unshift(item);
    ctpWrite(CTP_KEYS.WALLETS, list);
    State.addLog('Wallet agregada', wallet.name, 'info');
    return item;
  },
  removeCustomWallet(id) {
    const list = State.getCustomWallets().filter(w => w.id !== id);
    ctpWrite(CTP_KEYS.WALLETS, list);
    State.addLog('Wallet eliminada', id, 'warning');
  },

  /* ---------- Usuarios (demo local, sin backend) ---------- */
  getUsers() {
    const existing = ctpRead(CTP_KEYS.USERS, null);
    if (existing) return existing;
    const seed = [
      { name: 'Fondo Meridian — Tesorería', email: 'tesoreria@fondo-meridian.com', role: 'Administrador', lastAccess: Date.now() },
      { name: 'Ana Restrepo', email: 'ana.restrepo@fondo-meridian.com', role: 'Analista de riesgo', lastAccess: Date.now() - 86400000 },
      { name: 'Julián Cárdenas', email: 'julian.cardenas@fondo-meridian.com', role: 'Solo lectura', lastAccess: Date.now() - 3 * 86400000 },
    ];
    ctpWrite(CTP_KEYS.USERS, seed);
    return seed;
  },
  touchCurrentUser(email) {
    if (!email) return;
    const users = State.getUsers();
    const idx = users.findIndex(u => u.email === email);
    if (idx >= 0) users[idx].lastAccess = Date.now();
    else users.unshift({ name: email.split('@')[0], email, role: 'Administrador', lastAccess: Date.now() });
    ctpWrite(CTP_KEYS.USERS, users);
  },

  /* ---------- Logs de actividad ---------- */
  getLogs() { return ctpRead(CTP_KEYS.LOGS, []); },
  addLog(event, detail, level) {
    const logs = State.getLogs();
    logs.unshift({ ts: Date.now(), event, detail: detail || '', level: level || 'info' });
    ctpWrite(CTP_KEYS.LOGS, logs.slice(0, 60));
  },
};
