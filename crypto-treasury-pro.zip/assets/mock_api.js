/**
 * mock_api.js — Simulador de API institucional para Crypto Treasury Pro.
 * Genera datos dummy realistas y los hace "vivos" con jitter aleatorio cada
 * pocos segundos, para imitar un feed de precios/posiciones en tiempo real.
 * En una integración real, este archivo se reemplaza por llamadas fetch()
 * a los endpoints del backend (ver docs.html).
 */
const MockAPI = (() => {
  const BASE = {
    btc: { amount: 1240.50, price: 67900 },
    eth: { amount: 18320, price: 3180 },
    usdt: 98400000,
    usdc: 46765770,
    exchanges: { Binance: 28, 'Coinbase Custody': 24, Kraken: 15, Bitfinex: 10, 'Cold storage': 23 },
    liquidityByChain: { Ethereum: 55, Tron: 25, Polygon: 10, Arbitrum: 10 },
    volatility: { BTC: 58, ETH: 71, USDT: 0.4, USDC: 0.3 },
    var95: 4.20, var99: 6.80, drawdown: 12.4, riskScore: 42, riskAdj: 1.8,
    weeklyPerf: [280100000, 282400000, 279800000, 284000000, 286200000, 285100000, 287650000],
    onchainFlows: {
      in: [4.1, 2.8, 5.6, 3.2, 6.1, 4.4, 2.9, 5.8, 3.6, 7.2, 4.9, 3.1, 6.4, 5.2],
      out: [2.4, 3.1, 1.9, 4.2, 2.6, 3.8, 2.2, 3.4, 4.8, 2.1, 3.6, 2.9, 3.2, 2.7],
    },
    drawdownSeries: [0, -0.4, -0.9, -1.2, -2.1, -3.4, -4.0, -3.6, -4.8, -5.9, -6.7, -7.8, -8.6, -9.4, -10.2, -11.1, -12.4, -11.6, -10.8, -9.7, -8.5, -7.2, -6.0, -5.1, -4.3, -3.6, -2.8, -2.1, -1.4, -0.8],
    riskDist: { 'Riesgo de mercado': 45, 'Riesgo de liquidez': 20, 'Riesgo de contraparte': 20, 'Riesgo de contrato inteligente': 15 },
  };

  const BASE_WALLETS = [
    { id: 'cs1', name: 'Cold Storage Treasury #1', desc: 'Ledger Institutional · Ethereum', balance: 62400000, status: 'Activa', tag: 'CS' },
    { id: 'fb1', name: 'Hot Wallet Operaciones', desc: 'Fireblocks · Ethereum + Polygon', balance: 18900000, status: 'Activa', tag: 'FB' },
    { id: 'gs1', name: 'Multisig Treasury Safe', desc: 'Gnosis Safe 4/6 · Ethereum', balance: 41100000, status: 'Activa', tag: 'GS' },
    { id: 'tx1', name: 'Hot Wallet Trading Desk', desc: 'Tron · USDT operativo', balance: 9200000, status: 'Monitoreo', tag: 'TX' },
  ];

  const MOVEMENT_TEMPLATES = [
    { type: 'Depósito', asset: 'USDT', wallet: 'Cold Storage #1', up: true },
    { type: 'Retiro', asset: 'ETH', wallet: 'Trading Desk', up: false },
    { type: 'Transferencia', asset: 'USDC', wallet: 'Multisig Safe', up: null },
    { type: 'Depósito', asset: 'BTC', wallet: 'Cold Storage #1', up: true },
    { type: 'Staking', asset: 'ETH', wallet: 'Multisig Safe', up: false },
  ];

  let movements = [
    { hash: '0x9f2a…7c1d', type: 'Depósito', asset: 'USDT', amount: '+2,400,000', wallet: 'Cold Storage #1', status: 'Confirmado', up: true },
    { hash: '0x4b7e…e920', type: 'Retiro', asset: 'ETH', amount: '−320.15', wallet: 'Trading Desk', status: 'Confirmado', up: false },
    { hash: '0x1c8d…33af', type: 'Transferencia', asset: 'USDC', amount: '1,000,000', wallet: 'Multisig Safe', status: 'Confirmado', up: null },
    { hash: '0xa60f…9b21', type: 'Depósito', asset: 'BTC', amount: '+18.40', wallet: 'Cold Storage #1', status: 'Confirmado', up: true },
    { hash: '0x7e11…c405', type: 'Retiro', asset: 'USDT', amount: '−850,000', wallet: 'Hot Wallet Ops', status: 'Pendiente', up: false },
    { hash: '0xd329…1a7e', type: 'Staking', asset: 'ETH', amount: '−1,200.00', wallet: 'Multisig Safe', status: 'Confirmado', up: false },
    { hash: '0x55c2…f80b', type: 'Depósito', asset: 'USDC', amount: '+3,100,000', wallet: 'Trading Desk', status: 'Confirmado', up: true },
  ];

  const rnd = (min, max) => Math.random() * (max - min) + min;
  const jitter = (v, pct) => v * (1 + rnd(-pct, pct));
  const hex = () => Math.random().toString(16).slice(2, 6);

  let current = null;
  let listeners = [];
  let timer = null;

  function buildSnapshot() {
    const btcPrice = jitter(BASE.btc.price, 0.006);
    const ethPrice = jitter(BASE.eth.price, 0.008);
    const usdtVal = jitter(BASE.usdt, 0.0006);
    const usdcVal = jitter(BASE.usdc, 0.0006);
    const btcVal = BASE.btc.amount * btcPrice;
    const ethVal = BASE.eth.amount * ethPrice;
    const total = btcVal + ethVal + usdtVal + usdcVal;
    const stableRatio = ((usdtVal + usdcVal) / total) * 100;

    const volatility = {};
    Object.entries(BASE.volatility).forEach(([k, v]) => volatility[k] = +jitter(v, 0.03).toFixed(1));

    const exchanges = {};
    Object.entries(BASE.exchanges).forEach(([k, v]) => exchanges[k] = +jitter(v, 0.02).toFixed(1));

    return {
      ts: Date.now(),
      prices: { BTC: btcPrice, ETH: ethPrice, USDT: usdtVal / BASE.usdt, USDC: usdcVal / BASE.usdc },
      balances: {
        btc: { amount: BASE.btc.amount, value: btcVal },
        eth: { amount: BASE.eth.amount, value: ethVal },
        usdt: usdtVal,
        usdc: usdcVal,
        total, stableRatio,
      },
      exchanges,
      liquidityByChain: BASE.liquidityByChain,
      liquidity: {
        reserves: usdtVal + usdcVal,
        immediatePct: +jitter(92, 0.01).toFixed(1),
        lockedPct: +jitter(8, 0.03).toFixed(1),
        netFlow24h: +jitter(3.82, 0.15).toFixed(2),
      },
      risk: {
        score: Math.round(jitter(BASE.riskScore, 0.05)),
        var95: +jitter(BASE.var95, 0.03).toFixed(2),
        var99: +jitter(BASE.var99, 0.03).toFixed(2),
        drawdown: +jitter(BASE.drawdown, 0.02).toFixed(1),
        riskAdj: +jitter(BASE.riskAdj, 0.02).toFixed(2),
      },
      volatility,
      weeklyPerf: BASE.weeklyPerf,
      onchainFlows: BASE.onchainFlows,
      drawdownSeries: BASE.drawdownSeries,
      riskDist: BASE.riskDist,
      wallets: [...BASE_WALLETS],
      movements,
    };
  }

  function maybeAddMovement() {
    if (Math.random() > 0.35) return; // ~35% de probabilidad por tick
    const t = MOVEMENT_TEMPLATES[Math.floor(Math.random() * MOVEMENT_TEMPLATES.length)];
    const amt = (Math.random() * 900000 + 10000);
    const sign = t.up === true ? '+' : t.up === false ? '−' : '';
    movements = [{
      hash: '0x' + hex() + '…' + hex(),
      type: t.type, asset: t.asset,
      amount: sign + Math.round(amt).toLocaleString('en-US'),
      wallet: t.wallet, status: Math.random() > 0.15 ? 'Confirmado' : 'Pendiente',
      up: t.up,
    }, ...movements].slice(0, 10);
  }

  return {
    get() { if (!current) current = buildSnapshot(); return current; },
    start(intervalMs = 8000) {
      if (timer) return;
      current = buildSnapshot();
      timer = setInterval(() => {
        maybeAddMovement();
        current = buildSnapshot();
        listeners.forEach(fn => { try { fn(current); } catch (e) { console.warn(e); } });
      }, intervalMs);
    },
    stop() { clearInterval(timer); timer = null; },
    onTick(fn) { listeners.push(fn); },
  };
})();
