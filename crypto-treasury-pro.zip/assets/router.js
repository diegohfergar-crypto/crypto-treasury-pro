/**
 * router.js — Enrutamiento por hash (#/ruta), sin recargar la página.
 * Rutas: dashboard, liquidity, risk, alerts, wallets, admin
 */
const Router = (() => {
  const ROUTES = ['dashboard', 'liquidity', 'risk', 'alerts', 'wallets', 'admin'];
  const TITLES = {
    dashboard: ['Dashboard cripto', 'Visión consolidada de los activos digitales del fondo'],
    liquidity: ['Liquidez on-chain', 'Reservas, flujos y disponibilidad de stablecoins'],
    risk: ['Riesgo cripto', 'Volatilidad, VaR y exposición al riesgo del portafolio'],
    alerts: ['Alertas', 'Reglas configurables sobre las métricas del portafolio'],
    wallets: ['Wallets', 'Wallets y cuentas conectadas a la tesorería'],
    admin: ['Panel admin', 'Usuarios, configuración y actividad del sistema'],
  };

  let current = null;
  let onChange = null;

  function parse() {
    const raw = (location.hash || '').replace('#/', '').replace('#', '');
    return ROUTES.includes(raw) ? raw : 'dashboard';
  }

  function render() {
    const route = parse();
    current = route;

    document.querySelectorAll('.page').forEach(s => s.classList.remove('active'));
    const target = document.getElementById('page-' + route);
    if (target) target.classList.add('active');

    document.querySelectorAll('.nav-link').forEach(a => {
      a.classList.toggle('active', a.dataset.route === route);
    });

    const [title, subtitle] = TITLES[route];
    const titleEl = document.getElementById('pageTitle');
    const subEl = document.getElementById('pageSubtitle');
    if (titleEl) titleEl.textContent = title;
    if (subEl) subEl.textContent = subtitle;
    document.title = title + ' · Crypto Treasury Pro';

    document.getElementById('mobileNav')?.classList.add('hidden');
    if (typeof onChange === 'function') onChange(route);
    window.scrollTo({ top: 0, behavior: 'instant' in window ? 'instant' : 'auto' });
  }

  function go(route) {
    if (location.hash === '#/' + route) { render(); return; }
    location.hash = '#/' + route;
  }

  function init(changeCb) {
    onChange = changeCb;
    window.addEventListener('hashchange', render);
    render();
  }

  return { init, go, get current() { return current; } };
})();
