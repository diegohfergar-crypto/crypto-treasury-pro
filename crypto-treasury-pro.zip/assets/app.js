/* =========================================================================
   app.js — Orquestador principal de Crypto Treasury Pro
   ========================================================================= */
const fmtUSD = (n) => '$' + Math.round(n).toLocaleString('en-US');
const fmtCompact = (n) => new Intl.NumberFormat('en-US', { notation: 'compact', maximumFractionDigits: 2 }).format(n);
const fmtPct = (n, d = 1) => n.toFixed(d) + '%';

const TEAL = '#2FD1C4', TEAL_LINE = '#5FE3D6';
const CORAL = '#F0806B', MINT = '#5BD9A0', AMBER = '#F0B94D';
const GRID = 'rgba(148,197,196,0.08)';
const TICK = '#7C8D8D';

Chart.defaults.font.family = "'Inter', sans-serif";
Chart.defaults.font.size = 11;
Chart.defaults.color = TICK;

let charts = {};
let dataView = 'live'; // 'live' | 'empty' | 'error'
const pagesLoaded = { dashboard: false, liquidity: false, risk: false, alerts: false, wallets: false, admin: false };

/* ===================== ARRANQUE ===================== */
document.addEventListener('DOMContentLoaded', () => {
  applyTheme(State.getSettings().theme);
  wireLogin();
  wireGlobalUI();

  const session = State.getSession();
  if (session) {
    enterApp(session);
  } else {
    showLogin();
  }
});

function showLogin() {
  document.getElementById('screen-login').classList.add('active');
  document.getElementById('appShell').classList.add('hidden');
}

function enterApp(session) {
  document.getElementById('screen-login').classList.remove('active');
  document.getElementById('appShell').classList.remove('hidden');
  State.touchCurrentUser(session.email);

  document.getElementById('sessionEmail').textContent = session.email || 'Wallet institucional';
  document.getElementById('sessionWallet').textContent = (State.getWalletConn() || {}).address || '0x7a9F…4Ecb';

  MockAPI.start(7000);
  MockAPI.onTick(onLiveTick);
  buildTicker(MockAPI.get());

  Router.init(onRouteChange);
  refreshBell();
}

/* ===================== LOGIN / SESIÓN ===================== */
function wireLogin() {
  document.getElementById('loginForm').addEventListener('submit', (e) => {
    e.preventDefault();
    const email = document.getElementById('loginEmail').value.trim() || 'tesoreria@fondo-meridian.com';
    const btn = document.getElementById('credBtn');
    btn.innerHTML = '<span class="inline-flex items-center gap-2 justify-center w-full"><span class="spinner w-4 h-4"></span> Verificando…</span>';
    btn.disabled = true;
    setTimeout(() => {
      State.setSession({ email });
      enterApp(State.getSession());
    }, 1000);
  });

  document.getElementById('walletBtn').addEventListener('click', function () {
    if (this.dataset.state === 'connecting') return;
    this.dataset.state = 'connecting';
    document.getElementById('walletBtnLabel').textContent = 'Conectando con wallet…';
    this.querySelector('#walletBtnIcon').outerHTML = '<span class="spinner w-4 h-4 flex-shrink-0"></span>';
    setTimeout(() => {
      const addr = '0x' + Math.random().toString(16).slice(2, 6) + '…' + Math.random().toString(16).slice(2, 6);
      document.getElementById('walletAddress').textContent = addr;
      document.getElementById('walletBtn').classList.add('hidden');
      document.getElementById('walletConnected').classList.remove('hidden');
      document.getElementById('walletConnected').dataset.addr = addr;
    }, 1400);
  });

  document.getElementById('enterWithWalletBtn').addEventListener('click', () => {
    const addr = document.getElementById('walletConnected').dataset.addr || '0x7a9F…4Ecb';
    State.setWalletConn(addr);
    State.setSession({ email: null, wallet: addr });
    enterApp(State.getSession());
  });
}

function logout() {
  MockAPI.stop();
  State.clearSession();
  location.hash = '';
  document.getElementById('appShell').classList.add('hidden');
  showLogin();
}

/* ===================== NAV / GLOBAL UI ===================== */
function wireGlobalUI() {
  document.getElementById('logoutBtn').addEventListener('click', logout);
  document.getElementById('mobileNavToggle').addEventListener('click', () => document.getElementById('mobileNav').classList.toggle('hidden'));

  document.getElementById('stateMenuBtn').addEventListener('click', (e) => { e.stopPropagation(); toggleMenu('stateMenu'); });
  document.getElementById('bellBtn').addEventListener('click', (e) => { e.stopPropagation(); toggleMenu('alertsMenu'); });
  document.getElementById('settingsBtn').addEventListener('click', openSettingsModal);
  document.getElementById('exportBtn').addEventListener('click', exportAllData);

  document.querySelectorAll('[data-setview]').forEach(btn => btn.addEventListener('click', () => setDataView(btn.dataset.setview)));

  document.addEventListener('click', (e) => {
    if (!e.target.closest('#stateMenuBtn') && !e.target.closest('#stateMenu')) hideMenu('stateMenu');
    if (!e.target.closest('#bellBtn') && !e.target.closest('#alertsMenu')) hideMenu('alertsMenu');
  });

  // Settings modal
  document.getElementById('settingsForm').addEventListener('submit', (e) => {
    e.preventDefault();
    const fd = new FormData(e.target);
    const patch = {
      theme: fd.get('theme'), baseCurrency: fd.get('baseCurrency'),
      favoriteExchange: fd.get('favoriteExchange'), mainWallet: fd.get('mainWallet'),
    };
    State.saveSettings(patch);
    applyTheme(patch.theme);
    closeSettingsModal();
    showToast('Preferencias guardadas');
    refreshCurrentPage(true);
  });
  document.getElementById('settingsCloseBtn').addEventListener('click', closeSettingsModal);
  document.getElementById('settingsBackdrop').addEventListener('click', closeSettingsModal);
}

function toggleMenu(id) { document.getElementById(id).classList.toggle('hidden'); }
function hideMenu(id) { document.getElementById(id)?.classList.add('hidden'); }

function applyTheme(theme) {
  document.documentElement.setAttribute('data-theme', theme === 'light' ? 'light' : 'dark');
}

/* ===================== SETTINGS MODAL ===================== */
function openSettingsModal() {
  const s = State.getSettings();
  const form = document.getElementById('settingsForm');
  form.theme.value = s.theme;
  form.baseCurrency.value = s.baseCurrency;
  form.favoriteExchange.value = s.favoriteExchange;
  form.mainWallet.value = s.mainWallet;
  document.getElementById('settingsModal').classList.remove('hidden');
}
function closeSettingsModal() { document.getElementById('settingsModal').classList.add('hidden'); }

/* ===================== TICKER ===================== */
function buildTicker(snap) {
  const items = [
    { sym: 'BTC', px: snap.prices.BTC, d: '+2.14%', up: true },
    { sym: 'ETH', px: snap.prices.ETH, d: '−0.38%', up: false },
    { sym: 'USDT', px: snap.prices.USDT, d: '+0.01%', up: true },
    { sym: 'USDC', px: snap.prices.USDC, d: '−0.01%', up: false },
  ];
  const html = items.map(i => `
    <span class="flex items-center gap-1.5 px-5 border-r border-white/[0.06]">
      <span class="text-muted">${i.sym}</span>
      <span class="text-heading">$${i.px.toLocaleString('en-US', { maximumFractionDigits: i.sym === 'BTC' || i.sym === 'ETH' ? 0 : 4 })}</span>
      <span class="${i.up ? 'text-mint-400' : 'text-coral-400'}">${i.d}</span>
    </span>`).join('');
  document.getElementById('tickerA').innerHTML = html;
  document.getElementById('tickerB').innerHTML = html;
}

/* ===================== ROUTER CALLBACK ===================== */
function onRouteChange(route) {
  renderRouteState(route);
}

function refreshCurrentPage(force) {
  if (force) pagesLoaded[Router.current] = false;
  renderRouteState(Router.current);
}

function setLayers(name, visible) {
  ['skeleton', 'empty', 'error', 'content'].forEach(layer => {
    const el = document.getElementById(name + '-' + layer);
    if (el) el.classList.toggle('hidden', layer !== visible);
  });
}

function renderRouteState(name) {
  if (!name) return;
  if (dataView === 'empty') { setLayers(name, 'empty'); return; }
  if (dataView === 'error') { setLayers(name, 'error'); return; }

  if (!pagesLoaded[name]) {
    setLayers(name, 'skeleton');
    setTimeout(() => {
      pagesLoaded[name] = true;
      loadPage(name);
      setLayers(name, 'content');
    }, 700);
  } else {
    setLayers(name, 'content');
  }
}

function loadPage(name) {
  const snap = MockAPI.get();
  if (name === 'dashboard') renderDashboard(snap, true);
  if (name === 'liquidity') renderLiquidity(snap, true);
  if (name === 'risk') renderRisk(snap, true);
  if (name === 'alerts') renderAlertsPage(snap);
  if (name === 'wallets') renderWalletsPage(snap);
  if (name === 'admin') renderAdminPage();
}

function retrySync(name) {
  const btn = document.getElementById('retryBtn-' + name);
  btn.innerHTML = '<span class="inline-flex items-center gap-2"><span class="spinner w-4 h-4"></span> Sincronizando…</span>';
  State.addLog('Reintento de sincronización', name, 'warning');
  setTimeout(() => {
    dataView = 'live';
    updateStateUI();
    pagesLoaded[name] = false;
    renderRouteState(name);
  }, 1100);
}

function setDataView(view) {
  dataView = view;
  updateStateUI();
  hideMenu('stateMenu');
  if (view === 'error') State.addLog('Error de sincronización simulado', Router.current, 'error');
  renderRouteState(Router.current);
}

function updateStateUI() {
  const dot = document.getElementById('stateDot');
  const label = document.getElementById('stateLabel');
  if (dataView === 'live') { dot.className = 'w-1.5 h-1.5 rounded-full bg-mint-500 pulse-dot'; label.textContent = 'Datos en vivo'; }
  if (dataView === 'empty') { dot.className = 'w-1.5 h-1.5 rounded-full bg-[#5E6E6E]'; label.textContent = 'Sin datos'; }
  if (dataView === 'error') { dot.className = 'w-1.5 h-1.5 rounded-full bg-coral-400 pulse-dot err'; label.textContent = 'Error de sync.'; }
}

/* ===================== LIVE TICK (mock api) ===================== */
function onLiveTick(snap) {
  buildTicker(snap);
  if (dataView !== 'live') return;
  if (Router.current === 'dashboard' && pagesLoaded.dashboard) renderDashboard(snap, false);
  if (Router.current === 'liquidity' && pagesLoaded.liquidity) renderLiquidity(snap, false);
  if (Router.current === 'risk' && pagesLoaded.risk) renderRisk(snap, false);
  refreshBell();
}

function flash(el, up) {
  if (!el) return;
  el.classList.remove('flash-up', 'flash-down');
  void el.offsetWidth;
  el.classList.add(up ? 'flash-up' : 'flash-down');
}

/* ===================== HELPERS DE MONEDA BASE ===================== */
function convertFromUSD(usd, snap) {
  const cur = State.getSettings().baseCurrency;
  if (cur === 'ETH') return { value: usd / snap.prices.ETH, suffix: ' ETH', decimals: 2 };
  if (cur === 'USDC') return { value: usd, suffix: ' USDC', decimals: 0 };
  return { value: usd, suffix: ' USDT', decimals: 0 };
}

/* ===================== DASHBOARD ===================== */
function renderDashboard(snap, isFirstLoad) {
  const heroEl = document.getElementById('heroTotal');
  if (isFirstLoad) { animateHeroNumber(snap.balances.total); }
  else {
    const conv = convertFromUSD(snap.balances.total, snap);
    heroEl.textContent = conv.suffix === ' ETH' ? conv.value.toLocaleString('en-US', { maximumFractionDigits: 2 }) + conv.suffix : fmtUSD(conv.value);
    flash(heroEl, true);
  }

  document.getElementById('stableRatioLabel').textContent = fmtPct(snap.balances.stableRatio);
  document.getElementById('btcAmt').textContent = snap.balances.btc.amount.toLocaleString('en-US', { minimumFractionDigits: 2 });
  document.getElementById('btcVal').textContent = fmtCompact(snap.balances.btc.value);
  document.getElementById('ethAmt').textContent = Math.round(snap.balances.eth.amount).toLocaleString('en-US');
  document.getElementById('ethVal').textContent = fmtCompact(snap.balances.eth.value);
  document.getElementById('usdtVal').textContent = fmtCompact(snap.balances.usdt);
  document.getElementById('usdcVal').textContent = fmtCompact(snap.balances.usdc);

  const exLabels = Object.keys(snap.exchanges);
  const exValues = Object.values(snap.exchanges);

  if (isFirstLoad) {
    charts.stableRatio?.destroy();
    charts.stableRatio = new Chart(document.getElementById('chartStableRatio'), {
      type: 'doughnut',
      data: { labels: ['Stablecoins', 'BTC / ETH'], datasets: [{ data: [snap.balances.stableRatio, 100 - snap.balances.stableRatio], backgroundColor: [TEAL, '#20303A'], borderWidth: 0, cutout: '78%' }] },
      options: { plugins: { legend: { display: false }, tooltip: { enabled: false } }, animation: { animateRotate: true, duration: 1000 } }
    });

    charts.weeklyPerf?.destroy();
    charts.weeklyPerf = new Chart(document.getElementById('chartWeeklyPerf'), {
      type: 'line',
      data: {
        labels: ['Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb', 'Dom'],
        datasets: [{ data: snap.weeklyPerf, borderColor: TEAL, borderWidth: 2.5, pointRadius: 0, pointHoverRadius: 5, tension: 0.4, fill: true,
          backgroundColor: (ctx) => { const g = ctx.chart.ctx.createLinearGradient(0, 0, 0, 240); g.addColorStop(0, 'rgba(47,209,196,0.28)'); g.addColorStop(1, 'rgba(47,209,196,0)'); return g; } }]
      },
      options: { responsive: true, maintainAspectRatio: false,
        plugins: { legend: { display: false }, tooltip: { backgroundColor: '#0F1620', borderColor: 'rgba(47,209,196,0.25)', borderWidth: 1, padding: 10, titleColor: '#fff', bodyColor: '#CFFCF6', callbacks: { label: (c) => fmtUSD(c.parsed.y) } } },
        scales: { x: { grid: { display: false }, ticks: { color: TICK } }, y: { grid: { color: GRID }, ticks: { color: TICK, callback: (v) => fmtCompact(v) } } }
      }
    });

    charts.exchangeExposure?.destroy();
    charts.exchangeExposure = new Chart(document.getElementById('chartExchangeExposure'), {
      type: 'bar',
      data: { labels: exLabels, datasets: [{ data: exValues, backgroundColor: [TEAL, '#3FC0B5', '#2A9891', '#1F7A74', TEAL_LINE], borderRadius: 6, barThickness: 16 }] },
      options: { indexAxis: 'y', responsive: true, maintainAspectRatio: false,
        plugins: { legend: { display: false }, tooltip: { backgroundColor: '#0F1620', borderColor: 'rgba(47,209,196,0.25)', borderWidth: 1, padding: 10, titleColor: '#fff', bodyColor: '#CFFCF6', callbacks: { label: (c) => c.parsed.x + '%' } } },
        scales: { x: { grid: { color: GRID }, ticks: { color: TICK, callback: (v) => v + '%' } }, y: { grid: { display: false }, ticks: { color: '#C9D6D5' } } }
      }
    });

    const stableP = ((snap.balances.usdt / snap.balances.total) * 100);
    const stableC = ((snap.balances.usdc / snap.balances.total) * 100);
    const btcP = ((snap.balances.btc.value / snap.balances.total) * 100);
    const ethP = ((snap.balances.eth.value / snap.balances.total) * 100);
    charts.allocation?.destroy();
    charts.allocation = new Chart(document.getElementById('chartAllocation'), {
      type: 'pie',
      data: { labels: ['USDT', 'BTC', 'ETH', 'USDC'], datasets: [{ data: [stableP, btcP, ethP, stableC], backgroundColor: [TEAL, '#3FC0B5', '#0E8E88', '#9AF3E8'], borderColor: '#0B111A', borderWidth: 2 }] },
      options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { position: 'bottom', labels: { color: '#9FB0B0', boxWidth: 10, boxHeight: 10, padding: 14 } }, tooltip: { backgroundColor: '#0F1620', borderColor: 'rgba(47,209,196,0.25)', borderWidth: 1, padding: 10, titleColor: '#fff', bodyColor: '#CFFCF6', callbacks: { label: (c) => c.label + ': ' + c.parsed.toFixed(1) + '%' } } } }
    });
  } else {
    charts.stableRatio.data.datasets[0].data = [snap.balances.stableRatio, 100 - snap.balances.stableRatio];
    charts.stableRatio.update('none');
    charts.exchangeExposure.data.datasets[0].data = exValues;
    charts.exchangeExposure.update('none');
  }

  renderDashboardWallets(snap);
}

function renderDashboardWallets(snap) {
  const box = document.getElementById('dashWalletsList');
  const mainWallet = State.getSettings().mainWallet;
  box.innerHTML = snap.wallets.map((w, i) => `
    <div class="flex items-center gap-3 ${i < snap.wallets.length - 1 ? 'pb-3 border-b hr-hair' : ''}">
      <span class="w-8 h-8 rounded-lg bg-teal-500/10 text-teal-300 flex items-center justify-center flex-shrink-0 font-mono text-xs">${w.tag}</span>
      <div class="min-w-0 flex-1">
        <p class="text-sm text-heading truncate">${w.name} ${w.name === mainWallet ? '<span class="text-teal-300">★</span>' : ''}</p>
        <p class="text-xs text-faint">${w.desc}</p>
      </div>
      <div class="text-right">
        <p class="text-sm text-heading font-mono">${fmtCompact(w.balance)}</p>
        <p class="text-xs ${w.status === 'Activa' ? 'text-mint-400' : 'text-amber-400'}">${w.status}</p>
      </div>
    </div>`).join('');
}

function animateHeroNumber(target) {
  const el = document.getElementById('heroTotal');
  if (!el) return;
  const dur = 1100, start = performance.now();
  function tick(now) {
    const p = Math.min(1, (now - start) / dur);
    const eased = 1 - Math.pow(1 - p, 3);
    el.textContent = fmtUSD(eased * target);
    if (p < 1) requestAnimationFrame(tick);
  }
  requestAnimationFrame(tick);
}

/* ===================== LIQUIDEZ ===================== */
function renderLiquidity(snap, isFirstLoad) {
  document.getElementById('liqReserves').textContent = fmtCompact(snap.liquidity.reserves);
  document.getElementById('liqImmediate').textContent = fmtPct(snap.liquidity.immediatePct);
  document.getElementById('liqImmediateUsd').textContent = fmtCompact(snap.liquidity.reserves * (snap.liquidity.immediatePct / 100) * 1.85) ;
  document.getElementById('liqLocked').textContent = fmtPct(snap.liquidity.lockedPct);
  document.getElementById('liqNetFlow').textContent = (snap.liquidity.netFlow24h >= 0 ? '+$' : '−$') + Math.abs(snap.liquidity.netFlow24h).toFixed(2) + 'M';

  if (isFirstLoad) {
    renderMovements(snap.movements);
    const days14 = Array.from({ length: 14 }, (_, i) => 'D-' + (14 - i));
    charts.onchainFlows?.destroy();
    charts.onchainFlows = new Chart(document.getElementById('chartOnchainFlows'), {
      type: 'bar',
      data: { labels: days14, datasets: [
        { label: 'Entradas', data: snap.onchainFlows.in, backgroundColor: TEAL, borderRadius: 4, barPercentage: 0.6 },
        { label: 'Salidas', data: snap.onchainFlows.out.map(v => -v), backgroundColor: CORAL, borderRadius: 4, barPercentage: 0.6 }
      ] },
      options: { responsive: true, maintainAspectRatio: false,
        plugins: { legend: { display: false }, tooltip: { backgroundColor: '#0F1620', borderColor: 'rgba(47,209,196,0.25)', borderWidth: 1, padding: 10, titleColor: '#fff', bodyColor: '#CFFCF6', callbacks: { label: (c) => c.dataset.label + ': $' + Math.abs(c.parsed.y).toFixed(1) + 'M' } } },
        scales: { x: { grid: { display: false }, ticks: { color: TICK, maxRotation: 0, autoSkip: true, maxTicksLimit: 7 } }, y: { grid: { color: GRID }, ticks: { color: TICK, callback: (v) => '$' + v + 'M' } } }
      }
    });

    charts.liquidityChain?.destroy();
    charts.liquidityChain = new Chart(document.getElementById('chartLiquidityChain'), {
      type: 'doughnut',
      data: { labels: Object.keys(snap.liquidityByChain), datasets: [{ data: Object.values(snap.liquidityByChain), backgroundColor: [TEAL, '#3FC0B5', '#1F7A74', '#9AF3E8'], borderColor: '#0B111A', borderWidth: 2, cutout: '62%' }] },
      options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { position: 'bottom', labels: { color: '#9FB0B0', boxWidth: 10, boxHeight: 10, padding: 14 } }, tooltip: { backgroundColor: '#0F1620', borderColor: 'rgba(47,209,196,0.25)', borderWidth: 1, padding: 10, titleColor: '#fff', bodyColor: '#CFFCF6', callbacks: { label: (c) => c.label + ': ' + c.parsed + '%' } } } }
    });
  } else {
    renderMovements(snap.movements);
  }
}

function renderMovements(movements) {
  const body = document.getElementById('movementsBody');
  if (!body) return;
  body.innerHTML = movements.map(m => `
    <tr class="border-b hr-hair last:border-0 row-hover transition-colors">
      <td class="py-3 px-2 font-mono text-teal-300/90">${m.hash}</td>
      <td class="py-3 px-2 text-body2">${m.type}</td>
      <td class="py-3 px-2 text-muted">${m.asset}</td>
      <td class="py-3 px-2 font-mono ${m.up === true ? 'text-mint-400' : m.up === false ? 'text-coral-400' : 'text-heading'}">${m.amount}</td>
      <td class="py-3 px-2 text-muted">${m.wallet}</td>
      <td class="py-3 px-2"><span class="text-xs px-2 py-1 rounded-full ${m.status === 'Confirmado' ? 'bg-mint-500/10 text-mint-400' : 'bg-amber-400/10 text-amber-400'}">${m.status}</span></td>
    </tr>`).join('');
}

/* ===================== RIESGO ===================== */
function renderRisk(snap, isFirstLoad) {
  document.getElementById('riskScoreLabel').textContent = snap.risk.score;
  document.getElementById('var95Label').textContent = '−$' + snap.risk.var95.toFixed(2) + 'M';
  document.getElementById('var99Label').textContent = '−$' + snap.risk.var99.toFixed(2) + 'M';
  document.getElementById('drawdownLabel').textContent = '−' + snap.risk.drawdown.toFixed(1) + '%';
  document.getElementById('riskAdjLabel').textContent = snap.risk.riskAdj.toFixed(1) + '×';
  initGauge(snap.risk.score);

  if (isFirstLoad) {
    charts.drawdown?.destroy();
    const ddLabels = snap.drawdownSeries.map((_, i) => i + 1);
    charts.drawdown = new Chart(document.getElementById('chartDrawdown'), {
      type: 'line',
      data: { labels: ddLabels, datasets: [{ data: snap.drawdownSeries, borderColor: CORAL, borderWidth: 2, pointRadius: 0, pointHoverRadius: 4, tension: 0.35, fill: true,
        backgroundColor: (ctx) => { const g = ctx.chart.ctx.createLinearGradient(0, 0, 0, 220); g.addColorStop(0, 'rgba(240,128,107,0)'); g.addColorStop(1, 'rgba(240,128,107,0.22)'); return g; } }] },
      options: { responsive: true, maintainAspectRatio: false,
        plugins: { legend: { display: false }, tooltip: { backgroundColor: '#0F1620', borderColor: 'rgba(240,128,107,0.3)', borderWidth: 1, padding: 10, titleColor: '#fff', bodyColor: '#F0806B', callbacks: { title: (c) => 'Día ' + c[0].label, label: (c) => c.parsed.y + '%' } } },
        scales: { x: { grid: { display: false }, ticks: { color: TICK, maxTicksLimit: 8 } }, y: { grid: { color: GRID }, ticks: { color: TICK, callback: (v) => v + '%' } } }
      }
    });

    charts.riskDist?.destroy();
    charts.riskDist = new Chart(document.getElementById('chartRiskDist'), {
      type: 'pie',
      data: { labels: Object.keys(snap.riskDist), datasets: [{ data: Object.values(snap.riskDist), backgroundColor: [CORAL, AMBER, TEAL, '#9AF3E8'], borderColor: '#0B111A', borderWidth: 2 }] },
      options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { position: 'bottom', labels: { color: '#9FB0B0', boxWidth: 10, boxHeight: 10, padding: 12, font: { size: 10.5 } } }, tooltip: { backgroundColor: '#0F1620', borderColor: 'rgba(47,209,196,0.25)', borderWidth: 1, padding: 10, titleColor: '#fff', bodyColor: '#CFFCF6', callbacks: { label: (c) => c.label + ': ' + c.parsed + '%' } } } }
    });

    charts.volatility?.destroy();
    charts.volatility = new Chart(document.getElementById('chartVolatility'), {
      type: 'bar',
      data: { labels: Object.keys(snap.volatility), datasets: [{ data: Object.values(snap.volatility), backgroundColor: [TEAL, '#3FC0B5', '#1F7A74', '#20303A'], borderRadius: 8, barThickness: 46 }] },
      options: { responsive: true, maintainAspectRatio: false,
        plugins: { legend: { display: false }, tooltip: { backgroundColor: '#0F1620', borderColor: 'rgba(47,209,196,0.25)', borderWidth: 1, padding: 10, titleColor: '#fff', bodyColor: '#CFFCF6', callbacks: { label: (c) => 'Volatilidad anualizada: ' + c.parsed.y + '%' } } },
        scales: { x: { grid: { display: false }, ticks: { color: '#C9D6D5' } }, y: { grid: { color: GRID }, ticks: { color: TICK, callback: (v) => v + '%' } } }
      }
    });
  } else {
    charts.volatility.data.datasets[0].data = Object.values(snap.volatility);
    charts.volatility.update('none');
  }
}

function initGauge(score) {
  const arc = document.getElementById('gaugeArc');
  const needle = document.getElementById('gaugeNeedle');
  if (!arc || !needle) return;
  const circumference = 283;
  const pct = Math.max(0, Math.min(1, score / 100));
  arc.style.strokeDashoffset = String(circumference * (1 - pct));
  needle.setAttribute('transform', 'rotate(' + (-90 + pct * 180) + ' 100 100)');
}

/* ===================== METRICAS DISPONIBLES PARA ALERTAS ===================== */
function metricValue(metric, snap) {
  switch (metric) {
    case 'var95': return snap.risk.var95;
    case 'var99': return snap.risk.var99;
    case 'drawdown': return snap.risk.drawdown;
    case 'voleth': return snap.volatility.ETH;
    case 'volbtc': return snap.volatility.BTC;
    case 'stableratio': return snap.balances.stableRatio;
    case 'totalassets': return snap.balances.total / 1e6;
    case 'riskscore': return snap.risk.score;
    default: return 0;
  }
}
const METRIC_META = {
  var95: { label: 'VaR 95% (1 día)', unit: '$M' },
  var99: { label: 'VaR 99% (1 día)', unit: '$M' },
  drawdown: { label: 'Drawdown máximo (30d)', unit: '%' },
  voleth: { label: 'Volatilidad anualizada — ETH', unit: '%' },
  volbtc: { label: 'Volatilidad anualizada — BTC', unit: '%' },
  stableratio: { label: 'Ratio de stablecoins', unit: '%' },
  totalassets: { label: 'Activos totales', unit: '$M' },
  riskscore: { label: 'Score de riesgo', unit: '/100' },
};

function evalAlert(alert, snap) {
  const value = metricValue(alert.metric, snap);
  const breached = alert.comparator === 'lte' ? value <= alert.threshold : value >= alert.threshold;
  return { value, breached: alert.enabled && breached };
}

/* ===================== ALERTAS (página) ===================== */
function renderAlertsPage(snap) {
  const list = State.getAlerts();
  const box = document.getElementById('alertsList');
  box.innerHTML = list.map(a => {
    const { value, breached } = evalAlert(a, snap);
    const near = !breached && a.enabled && (value / a.threshold) >= 0.85 && a.comparator === 'gte';
    const statusCls = breached ? 'bg-coral-500/15 text-coral-400' : near ? 'bg-amber-400/15 text-amber-400' : a.enabled ? 'bg-mint-500/15 text-mint-400' : 'bg-white/5 text-faint';
    const statusLabel = breached ? 'Superado' : near ? 'Cerca del límite' : a.enabled ? 'Normal' : 'Desactivada';
    return `
    <div class="glass-dense rounded-xl p-4 flex flex-col sm:flex-row sm:items-center gap-3">
      <input type="checkbox" ${a.enabled ? 'checked' : ''} class="tgl" onchange="Alerts.toggle('${a.id}', this.checked)">
      <div class="flex-1 min-w-0">
        <p class="text-sm text-heading">${a.label}</p>
        <p class="text-xs text-faint font-mono mt-0.5">valor actual: ${value.toFixed(2)}${a.unit === '$M' ? 'M' : a.unit === '/100' ? '' : '%'} · umbral ${a.comparator === 'lte' ? '≤' : '≥'} <input type="number" step="0.1" value="${a.threshold}" onchange="Alerts.setThreshold('${a.id}', this.value)" class="input-base w-20 rounded-md px-1.5 py-0.5 ml-1"> ${a.unit === '$M' ? 'M' : a.unit === '/100' ? '' : '%'}</p>
      </div>
      <span class="text-xs px-2.5 py-1 rounded-full ${statusCls} whitespace-nowrap">${statusLabel}</span>
      <button onclick="Alerts.remove('${a.id}')" class="text-faint hover:text-coral-400 transition-colors flex-shrink-0" title="Eliminar alerta">
        <svg viewBox="0 0 24 24" class="w-4 h-4" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M4 7h16M9 7V5a2 2 0 012-2h2a2 2 0 012 2v2m2 0v13a2 2 0 01-2 2H8a2 2 0 01-2-2V7h12z"/></svg>
      </button>
    </div>`;
  }).join('') || '<p class="text-sm text-faint text-center py-10">No hay alertas configuradas todavía.</p>';

  const breachedCount = list.filter(a => evalAlert(a, snap).breached).length;
  const summary = document.getElementById('alertsSummary');
  summary.textContent = breachedCount === 0 ? 'Todas las métricas dentro de rango' : breachedCount + (breachedCount === 1 ? ' alerta activa' : ' alertas activas');
  summary.className = 'text-xs px-2.5 py-1 rounded-full ' + (breachedCount === 0 ? 'bg-mint-500/10 text-mint-400' : 'bg-coral-500/10 text-coral-400');
}

const Alerts = {
  toggle(id, checked) { State.updateAlert(id, { enabled: checked }); renderAlertsPage(MockAPI.get()); refreshBell(); },
  setThreshold(id, val) { State.updateAlert(id, { threshold: parseFloat(val) || 0 }); renderAlertsPage(MockAPI.get()); refreshBell(); },
  remove(id) { State.deleteAlert(id); renderAlertsPage(MockAPI.get()); refreshBell(); showToast('Alerta eliminada'); },
};

function wireNewAlertForm() {
  const sel = document.getElementById('newAlertMetric');
  if (sel && !sel.dataset.wired) {
    sel.dataset.wired = '1';
    sel.innerHTML = Object.entries(METRIC_META).map(([k, v]) => `<option value="${k}">${v.label}</option>`).join('');
  }
  const form = document.getElementById('newAlertForm');
  if (form && !form.dataset.wired) {
    form.dataset.wired = '1';
    form.addEventListener('submit', (e) => {
      e.preventDefault();
      const fd = new FormData(form);
      const metric = fd.get('metric');
      const meta = METRIC_META[metric];
      State.addAlert({ metric, label: meta.label, unit: meta.unit, comparator: fd.get('comparator'), threshold: parseFloat(fd.get('threshold')) || 0 });
      form.reset();
      renderAlertsPage(MockAPI.get());
      refreshBell();
      showToast('Alerta creada');
    });
  }
}

function refreshBell() {
  const snap = MockAPI.get();
  const list = State.getAlerts();
  const breached = list.filter(a => evalAlert(a, snap).breached);
  const badge = document.getElementById('bellBadge');
  const navBadge = document.getElementById('navAlertsBadge');
  [badge, navBadge].forEach(b => { if (!b) return; b.textContent = breached.length; b.classList.toggle('hidden', breached.length === 0); });

  const menuList = document.getElementById('alertsMenuList');
  menuList.innerHTML = breached.length === 0
    ? '<p class="text-xs text-faint py-2">Sin alertas activas.</p>'
    : breached.map(a => `
      <div class="flex items-start gap-2 text-xs bg-coral-500/[0.06] border border-coral-500/15 rounded-lg px-2.5 py-2">
        <span class="w-1.5 h-1.5 rounded-full bg-coral-400 mt-1 flex-shrink-0"></span>
        <div><p class="text-body2">${a.label}</p><p class="text-faint font-mono mt-0.5">umbral ${a.comparator === 'lte' ? '≤' : '≥'} ${a.threshold}${a.unit === '$M' ? 'M' : a.unit === '/100' ? '' : '%'}</p></div>
      </div>`).join('');
}

/* ===================== WALLETS (página) ===================== */
function renderWalletsPage(snap) {
  wireNewWalletForm();
  const custom = State.getCustomWallets();
  const all = [...snap.wallets.map(w => ({ ...w, custom: false })), ...custom.map(w => ({ ...w, custom: true }))];
  const mainWallet = State.getSettings().mainWallet;
  const box = document.getElementById('walletsList');
  box.innerHTML = all.map(w => `
    <div class="glass-dense rounded-xl p-4 flex items-center gap-3">
      <span class="w-9 h-9 rounded-lg bg-teal-500/10 text-teal-300 flex items-center justify-center flex-shrink-0 font-mono text-xs">${(w.tag || w.name.slice(0, 2)).toUpperCase()}</span>
      <div class="min-w-0 flex-1">
        <p class="text-sm text-heading truncate">${w.name} ${w.name === mainWallet ? '<span class="text-teal-300">★ principal</span>' : ''}</p>
        <p class="text-xs text-faint">${w.desc || w.network || ''}</p>
      </div>
      <div class="text-right mr-2">
        <p class="text-sm text-heading font-mono">${fmtCompact(w.balance || 0)}</p>
        <p class="text-xs ${w.status === 'Activa' ? 'text-mint-400' : 'text-amber-400'}">${w.status}</p>
      </div>
      ${w.custom ? `<button onclick="removeWallet('${w.id}')" class="text-faint hover:text-coral-400 flex-shrink-0" title="Quitar"><svg viewBox="0 0 24 24" class="w-4 h-4" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M4 7h16M9 7V5a2 2 0 012-2h2a2 2 0 012 2v2m2 0v13a2 2 0 01-2 2H8a2 2 0 01-2-2V7h12z"/></svg></button>` : ''}
    </div>`).join('');
}

function wireNewWalletForm() {
  const form = document.getElementById('newWalletForm');
  if (form && !form.dataset.wired) {
    form.dataset.wired = '1';
    form.addEventListener('submit', (e) => {
      e.preventDefault();
      const fd = new FormData(form);
      State.addCustomWallet({ name: fd.get('name'), desc: fd.get('network'), balance: parseFloat(fd.get('balance')) || 0, tag: (fd.get('name') || 'W').slice(0, 2).toUpperCase() });
      form.reset();
      renderWalletsPage(MockAPI.get());
      showToast('Wallet agregada');
    });
  }
}
function removeWallet(id) { State.removeCustomWallet(id); renderWalletsPage(MockAPI.get()); showToast('Wallet eliminada'); }

/* ===================== ADMIN (página) ===================== */
function renderAdminPage() {
  const users = State.getUsers();
  document.getElementById('adminUsers').innerHTML = users.map(u => `
    <tr class="border-b hr-hair last:border-0 row-hover">
      <td class="py-2.5 px-2 text-body2">${u.name}</td>
      <td class="py-2.5 px-2 text-faint font-mono">${u.email}</td>
      <td class="py-2.5 px-2"><span class="text-xs px-2 py-0.5 rounded-full bg-teal-500/10 text-teal-300">${u.role}</span></td>
      <td class="py-2.5 px-2 text-faint">${new Date(u.lastAccess).toLocaleString('es-CO')}</td>
    </tr>`).join('');

  const s = State.getSettings();
  document.getElementById('adminSettings').innerHTML = Object.entries(s).map(([k, v]) => `
    <div class="flex items-center justify-between py-2 border-b hr-hair last:border-0">
      <span class="text-faint">${k}</span><span class="font-mono text-body2">${v}</span>
    </div>`).join('');

  const logs = State.getLogs();
  document.getElementById('adminLogs').innerHTML = logs.length ? logs.map(l => `
    <tr class="border-b hr-hair last:border-0 row-hover">
      <td class="py-2 px-2 text-faint font-mono whitespace-nowrap">${new Date(l.ts).toLocaleTimeString('es-CO')}</td>
      <td class="py-2 px-2 text-body2">${l.event}</td>
      <td class="py-2 px-2 text-faint">${l.detail}</td>
      <td class="py-2 px-2"><span class="text-xs px-2 py-0.5 rounded-full ${l.level === 'error' ? 'bg-coral-500/10 text-coral-400' : l.level === 'warning' ? 'bg-amber-400/10 text-amber-400' : 'bg-mint-500/10 text-mint-400'}">${l.level}</span></td>
    </tr>`).join('') : '<tr><td colspan="4" class="py-6 text-center text-faint text-sm">Sin actividad registrada todavía.</td></tr>';
}

/* ===================== EXPORT JSON ===================== */
function exportAllData() {
  const snap = MockAPI.get();
  const payload = {
    exportedAt: new Date().toISOString(),
    balances: snap.balances,
    liquidity: snap.liquidity,
    risk: snap.risk,
    volatility: snap.volatility,
    alerts: State.getAlerts(),
    wallets: [...snap.wallets, ...State.getCustomWallets()],
    settings: State.getSettings(),
  };
  const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = 'crypto-treasury-pro-export-' + Date.now() + '.json';
  document.body.appendChild(a); a.click(); a.remove();
  URL.revokeObjectURL(url);
  State.addLog('Exportación de datos', 'JSON descargado', 'info');
  showToast('Datos exportados (JSON)');
}

/* ===================== TOAST ===================== */
let toastTimer;
function showToast(msg) {
  const t = document.getElementById('toast');
  document.getElementById('toastMsg').textContent = msg;
  t.classList.remove('hidden');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => t.classList.add('hidden'), 2600);
}

/* hook the alerts/wallets page forms once DOM is ready each time route changes */
document.addEventListener('DOMContentLoaded', () => {
  wireNewAlertForm();
});
const _origLoadPage = loadPage;
loadPage = function (name) {
  _origLoadPage(name);
  if (name === 'alerts') wireNewAlertForm();
  if (name === 'wallets') wireNewWalletForm();
};
